package tugaskelompok;

public class Main {
    public static void main(String[] args) {
        Form code = new Form();
        code.setVisible(true);
    }
}
